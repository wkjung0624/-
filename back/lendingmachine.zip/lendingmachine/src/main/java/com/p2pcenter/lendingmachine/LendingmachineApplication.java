package com.p2pcenter.lendingmachine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LendingmachineApplication {

	public static void main(String[] args) {
		SpringApplication.run(LendingmachineApplication.class, args);
	}

}
