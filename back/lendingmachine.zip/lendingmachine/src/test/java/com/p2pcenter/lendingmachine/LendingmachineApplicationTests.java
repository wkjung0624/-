package com.p2pcenter.lendingmachine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LendingmachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
